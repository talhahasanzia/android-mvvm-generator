#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.domain

#end
#parse("File Header.java")
import ${PACKAGE_NAME}.api.${NAME}Service
import ${PACKAGE_NAME}.models.${NAME}Request
import ${PACKAGE_NAME}.models.${NAME}State
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

interface ${NAME}UseCase : BaseUseCase<${NAME}Request, Flow<${NAME}State>>

class Default${NAME}UseCase @Inject constructor(
    private val service: ${NAME}Service,
) : ${NAME}UseCase {

    override suspend fun execute(request: ${NAME}Request): Flow<${NAME}State> {
        return flow {
            emit(${NAME}State.Loading)

         
        }
    }
}