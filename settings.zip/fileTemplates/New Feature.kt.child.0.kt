#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.models

#end
#parse("File Header.java")
sealed class ${NAME}State {
  data class Success( val data : String ) : ${NAME}State()
  data class Failure( val data : String ) : ${NAME}State()
  object Loading : ${NAME}State()  
}