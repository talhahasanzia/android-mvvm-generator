#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.api

#end
#parse("File Header.java")
import ${PACKAGE_NAME}.models.${NAME}RequestDto
import ${PACKAGE_NAME}.models.${NAME}Response
import retrofit2.http.Body
import retrofit2.http.GET

interface ${NAME}Api {
    @GET("resource")
    suspend fun get${NAME}(
        @Body body: ${NAME}RequestDto,
    ): ${NAME}Response
}