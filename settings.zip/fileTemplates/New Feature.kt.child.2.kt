#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.api

#end
#parse("File Header.java")

import ${PACKAGE_NAME}.models.${NAME}Request
import ${PACKAGE_NAME}.models.${NAME}RequestDto
import ${PACKAGE_NAME}.models.${NAME}Response
import javax.inject.Inject

interface ${NAME}Service {
    suspend fun get(request : ${NAME}Request) : Resource<out ${NAME}Response>
}

class Default${NAME}Service @Inject constructor(
    private val api: ${NAME}Api,
    private val dispatcher: CoroutineDispatcher,
    private val stringResourceProvider: StringResourceProvider
) : ${NAME}Service, BaseService(dispatcher, stringResourceProvider) {

   override suspend fun get(request : ${NAME}Request) : Resource<out ${NAME}Response> {
return requestApiResource { api.get${NAME}(${NAME}RequestDto(request.data)) }   }
}