#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.models

#end
#parse("File Header.java")
import com.squareup.moshi.JsonClass

@JsonClass( generateAdapter = true )
data class ${NAME}Response(
 val data : String
)