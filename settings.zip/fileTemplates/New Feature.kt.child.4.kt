#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.di

#end
#parse("File Header.java")
import ${PACKAGE_NAME}.api.${NAME}Api
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import retrofit2.Retrofit

@Module
@InstallIn(ViewModelComponent::class)
class ${NAME}Module {
    @Provides
    fun provideChangePasswordApi(retrofit: Retrofit): ${NAME}Api {
        return retrofit.create(${NAME}Api::class.java)
    }
}