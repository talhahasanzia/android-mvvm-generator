#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.models

#end
#parse("File Header.java")
data class ${NAME}Request(
 val data : String
)