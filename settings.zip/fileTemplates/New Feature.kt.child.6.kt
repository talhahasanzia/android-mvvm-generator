#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.di

#end
#parse("File Header.java")
import ${PACKAGE_NAME}.api.${NAME}Service
import ${PACKAGE_NAME}.api.Default${NAME}Service
import ${PACKAGE_NAME}.domain.${NAME}UseCase
import ${PACKAGE_NAME}.domain.Default${NAME}UseCase
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
abstract class ${NAME}Bindings {

    @Binds
    abstract fun bind${NAME}Service(default: Default${NAME}Service): ${NAME}Service

    @Binds
    abstract fun bind${NAME}UseCase(default: Default${NAME}UseCase): ${NAME}UseCase
}