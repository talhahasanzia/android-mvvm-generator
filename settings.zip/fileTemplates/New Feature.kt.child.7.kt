#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.vm

#end
#parse("File Header.java")
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ${PACKAGE_NAME}.models.${NAME}Request
import ${PACKAGE_NAME}.models.${NAME}State
import ${PACKAGE_NAME}.domain.${NAME}UseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ${NAME}ViewModel @Inject constructor(
    private val useCase: ${NAME}UseCase,
    private val stringRes: StringResourceProvider
) :
    ViewModel() {

    private val _state = MutableLiveData<${NAME}State>()
    val state: LiveData<${NAME}State>
        get() = _state

 fun getData() {
        viewModelScope.launch { 
            useCase.execute(${NAME}Request("")).collectLatest { 
                
            }
        }
    }
    
}